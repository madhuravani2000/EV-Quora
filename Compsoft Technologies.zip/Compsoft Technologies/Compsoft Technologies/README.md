# Confer_space
## 🏄 Introduction
This is a discussion forum where people come give thair review and some of questions answers.
	
## Installation
## Ubuntu
You should download  [xampp web server](https://www.apachefriends.org/download.html)

Step 1: Open Terminal (Tip:- To open terminal Ctrl+Alt+T)	

To run this application you have to download `confer.sql` file and import using xampp software
then download confer_space repo and paste that folder into `htdocs`
after that run `localhost\confer_space`
	
## 💻 Overview of the files

> 1.  confer.sql - It is mySQL data base file. 
> 2.  Confer_space/Confer_Space/admin/ - This folder contains admin page
> 3.  index.php - This is the main file that u have run it 


**[DEMO](https://youtu.be/dHFC48ubNoA)**
