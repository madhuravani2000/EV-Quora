<?php
$conn=mysqli_connect("localhost","root","","Compsoft Technologies")or die("Could not connect to mysql".mysql_error($conn));
?>